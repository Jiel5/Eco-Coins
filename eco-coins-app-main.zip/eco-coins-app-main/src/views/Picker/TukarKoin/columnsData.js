export const columnsDataTukarKoin = [
  {
    Header: "Penukar Koin",
    accessor: "id_pengguna",
  },
  {
    Header: "Jumlah Koin",
    accessor: "id_nilai_tukar_koin",
  },
  {
    Header: "Jumlah Uang",
    accessor: "jumlah_uang",
  },
  {
    Header: "Pengepul",
    accessor: "id_pengepul",
  },
  {
    Header: "Tanggal",
    accessor: "tanggal",
  },
  {
    Header: "Keterangan",
    accessor: "keterangan",
  },
  {
    Header: "Status",
    accessor: "status",
  },
];
