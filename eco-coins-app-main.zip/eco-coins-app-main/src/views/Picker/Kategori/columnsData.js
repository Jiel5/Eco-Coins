export const columnsDataJenisSampah = [
  {
    Header: "Jenis Sampah",
    accessor: "jenis_sampah",
  },
  {
    Header: "Nilai Koin Per KG",
    accessor: "nilai_koin_per_kg",
  },
];
