export const columnsDataNilaiKoin = [
  {
    Header: "Nilai Koin",
    accessor: "nilai_koin",
  },
  {
    Header: "Nilai Uang (Rp)",
    accessor: "nilai_uang",
  },
];
