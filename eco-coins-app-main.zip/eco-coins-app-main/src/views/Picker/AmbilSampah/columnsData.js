export const columnsDataAmbilSampah = [
  {
    Header: "Pembuang",
    accessor: "Pengguna",
  },
  {
    Header: "Alamat",
    accessor: "id_pengguna",
  },
  {
    Header: "Jenis sampah",
    accessor: "Sampah",
  },
  {
    Header: "Berat",
    accessor: "berat_kg",
  },
  {
    Header: "Jumlah Koin",
    accessor: "jumlah_koin",
  },
  {
    Header: "Tanggal",
    accessor: "tanggal",
  },
  {
    Header: "Status",
    accessor: "status",
  },
];
