export const columnsDataBuangSampah = [
  {
    Header: "Pengepul",
    accessor: "Pengepul",
  },
  {
    Header: "Jenis sampah",
    accessor: "Sampah",
  },
  {
    Header: "Berat",
    accessor: "berat_kg",
  },
  {
    Header: "Jumlah Koin",
    accessor: "jumlah_koin",
  },
  {
    Header: "Tanggal",
    accessor: "tanggal",
  },
  {
    Header: "Status",
    accessor: "status",
  },
];
