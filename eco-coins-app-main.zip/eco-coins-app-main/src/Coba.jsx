import { MdHome } from "react-icons/md";

const Coba = () => {
  return (
    <div>
      <p className="flex">
        <a href="/admin">coba</a> <MdHome className="h-6 w-6 text-green-500" />
      </p>
    </div>
  );
};

export default Coba;
